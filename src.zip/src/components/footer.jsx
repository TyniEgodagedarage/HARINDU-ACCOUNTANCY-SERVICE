export const Footer = (props) => {
  
  return (
    <div>
      <div id='footer'>
        <div className='container text-center'>
          <p>
            &copy; Tyni Egodagedarge React frontend development{' '}
            
           
          </p>
        </div>
      </div>
    </div>
  )
}
